# Editable manuscript and analysis figures

Updated for the 23 October 2026 author manuscript.

- Figures 3-8: ten-model comparisons. Figure 5 includes all models in its task-level heatmaps. Figure 8 examines goal completion and execution recovery in all 100 adopted CALVIN episodes.
- Figures 1-2: the task overview and benchmark construction. All eight main-text canvases omit descriptive titles and explanatory prose; captions carry definitions and measurement details. Axes, units, model identities and data labels remain in the native drawing.
- Figures 6-8 use rounded vertical bars; supplement-figure6/7 retain the fine-grained diagnostics in the appendix.
- Model identity colours follow the supplied logo families, with shades and line styles distinguishing models. Numerical heatmaps retain common scales. See model-logos/palette.json.
- model-task-comparison: the README comparison, using the updated Table 2 means.
- cases-affordance: selected qualitative polygon examples. The online Case Atlas compares all ten models on each image.
- execution-progress: exact-task Archaeology Dating progress; planning-execution-profile: ten-model Planning resources. Data and definitions for the new Spatial and CALVIN diagnostics are in public/data/spatial-recovery/.

Model names distinguish Gemini 3.8 Flash (Gemini 3.8) from Gemini 4 Argon (Gemini 4).

Open .drawio files in draw.io / diagrams.net to edit the vector objects. SVG and PDF are vector exports; PNG is a preview. Keep the Comic Sans MS typeface installed when re-exporting to preserve the manuscript typography. Photographs and model logos retain their source formats and attribution; see model-logos/.

figure-manifest.json records exact file hashes and experiment scopes. These are editable sources and exports, not a complete raw-log plotting pipeline.
