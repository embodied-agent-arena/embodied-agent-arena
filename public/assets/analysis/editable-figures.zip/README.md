# Editable manuscript and analysis figures

Updated for the 22 October 2026 author manuscript.

- Figures 3-8: Gemini 4 Argon included in the main comparisons. Original observation-setting ablation panels keep their original cohort.
- Figures 6-7 use rounded vertical bars; supplement-figure6/7 retain the fine-grained diagnostics in the appendix.
- Model identity colours follow the supplied logo families, with shades and line styles distinguishing models. Numerical heatmaps retain common scales. See model-logos/palette.json.
- model-task-comparison: the README comparison, using the unchanged Table 2 means.
- cases-affordance: selected qualitative polygon examples. The online Case Atlas compares all ten models on each image.
- execution-progress and planning-execution-profile: ten-model Planning resource analysis and exact-task progress comparisons including Gemini 4 Argon.

Open .drawio files in draw.io / diagrams.net to edit the vector objects. SVG and PDF are vector exports; PNG is a preview. Keep the Comic Sans MS typeface installed when re-exporting to preserve the manuscript typography. Photographs and model logos retain their source formats and attribution; see model-logos/.

figure-manifest.json records exact file hashes and experiment scopes. These are editable sources and exports, not a complete raw-log plotting pipeline.

Model labels always distinguish Gemini 3.8 Flash (Gemini 3.8) from Gemini 4 Argon (Gemini 4). Numeric results and raw model identifiers are unchanged.
